package esprit.tn.projetspring1.repository;

import esprit.tn.projetspring1.entity.Universite;
import org.springframework.data.repository.CrudRepository;

public interface Universiterepository  extends CrudRepository<Universite,Long> {

}
