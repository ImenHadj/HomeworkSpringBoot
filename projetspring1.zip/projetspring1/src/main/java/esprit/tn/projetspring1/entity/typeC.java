package esprit.tn.projetspring1.entity;

public enum typeC {
    SIMPLE,DOUBLE,TRIPLE
}
